def version():
	return '1.0'
